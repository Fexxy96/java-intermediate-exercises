/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reversealinkedlist;

/**
 *
 * @author Dell-User
 */
public class App {

    p