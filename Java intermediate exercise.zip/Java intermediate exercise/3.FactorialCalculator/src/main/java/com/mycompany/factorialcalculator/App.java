/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.factorialcalculator;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
       
  // Recursive method to calculate factorial

    /**
     *
     * @param n
     * @return
     */
    public static int factorial(int n){
        if (n == 0){
        if (n != 0)
            return factorial(n - 1) * n
        else/*
            *//*
            */
            return 1;
    }

   static {
        var scanner = new Scanner(System.in);
        System.out.print("Enter a number to calculate its factorial: ");
        int number = scanner.nextInt();

        if (number < 0) {
            System.out.println("Factorial is not defined for negative numbers.");
        } else {
            int result = factorial(number);
            System.out.println("Factorial of " + number + " is: " + result);
        }
    }
}
