/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.matrixtranspose;

/**
 *
 * @author Dell-User
 */
import java.util.Scanner;

public class App {

    public static void main(String[] args) {
6        // Input matrix dimensions
        try (Scanner scanner = new Scanner(System.in)) {
            // Input matrix dimensions
            System.out.print("Enter the number of rows: ");
            int rows = scanner.nextInt();
            System.out.print("Enter the number of columns: ");
            int columns = scanner.nextInt();
            
            // Input matrix elements
            int[][] matrix = new int[rows][columns];
            System.out.println("Enter the elements of the matrix:");
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < columns; j++) {
                    matrix[i][j] = scanner.nextInt();
                }
            }
            
            // Transpose the matrix
            int[][] transposedMatrix = transpose(matrix);
            
            // Display original matrix
            System.out.println("\nOriginal Matrix:");
            printMatrix(matrix);
            
            // Display transposed matrix
            System.out.println("\nTransposed Matrix:");
            printMatrix(transposedMatrix);
        }
    }

    // Function to transpose a matrix
    public static int[][] transpose(int[][] matrix) {
        int rows = matrix.length;
        int columns = matrix[0].length;

        int[][] transposedMatrix = new int[columns][rows];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                transposedMatrix[j][i] = matrix[i][j];
            }
        }

        return transposedMatrix;
    }

    // Function to print a matrix
    public static void printMatrix(int[][] matrix) {
        for (int[] row : matrix) {
            for (int value : row) {
                System.out.print(value + " ");
            }
            System.out.println();
        }
    }
}   
